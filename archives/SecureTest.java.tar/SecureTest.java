import org.junit.BeforeClass;

public abstract class SecureTest {

    @BeforeClass
    public static void startup() {
        if (System.getSecurityManager() == null) {
            System.setSecurityManager(new SecurityManager());
        }
    }
}
